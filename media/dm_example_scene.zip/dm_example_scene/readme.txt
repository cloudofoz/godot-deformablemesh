Example Scene for DeformableMesh v0.30

MIT License - (C) Claudio Z. 2024 - www.github.com/cloudofoz/godot-deformablemesh


0) Unzip this folder
1) Import the project with Godot Engine
2) Open the scene dm_example_scene_v030.tscn (if it's not already opened)

This scene shows some of the functionalities of this addon. You can try tweaking the deformer parameters. 
Some effects are also controlled by the positions and the rotations of the deformer nodes.

DeformableMesh can apply multiple deformations like in a stack, so the order is important to achieve the correct effect.
It's also important to specify the correct deformation axis (for some deformations like bending, but it's not important with spherical deformers).

